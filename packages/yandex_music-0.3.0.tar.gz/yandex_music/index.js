'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { promisify } = require('node:util');
const execFile = promisify(require('node:child_process').execFile);
const Q = require('kew');
const ApiClient = require('./lib/api-client');
const Browse = require('./lib/browse');
const Playback = require('./lib/playback');
const Wave = require('./lib/wave');
const { createTransportWithManager, probeStream } = require('./lib/transport');
const { LocalFileInfo } = require('./lib/local-file-info');

function kew(promise) {
  const deferred = Q.defer();
  Promise.resolve(promise).then(value => deferred.resolve(value), error => deferred.reject(error));
  return deferred.promise;
}

class ControllerYandexMusic {
  constructor(context, dependencies = {}) {
    this.context = context; this.router = context.coreCommand; this.logger = context.logger;
    this.api = dependencies.api;
    this.service = dependencies.service || {
      start: () => execFile('/usr/bin/sudo', ['-n', '/bin/systemctl', 'start', 'volumio-yandex.service']),
      stop: () => execFile('/usr/bin/sudo', ['-n', '/bin/systemctl', 'stop', 'volumio-yandex.service'])
    };
    this.started = false; this.loginGeneration = 0; this.login = null; this.timer = null;
    this.lifecycleGeneration = 0; this.shutdownGeneration = -1; this.startPromise = null;
    this.quality = 'auto';
    this.localFiles = new LocalFileInfo();
  }
  qualityPath() {
    const get = this.router.pluginManager.getConfigurationFile;
    return typeof get === 'function' ? path.join(path.dirname(get.call(this.router.pluginManager, this.context, 'api-key')), 'quality.json') : null;
  }
  loadQuality() {
    try {
      const quality = JSON.parse(fs.readFileSync(this.qualityPath(), 'utf8')).quality;
      if (['auto', 'lossless', 'mp3'].includes(quality)) this.quality = quality;
    } catch { /* missing settings use the default */ }
  }
  t(key) {
    const lang = this.router.sharedVars?.get('language_code')?.startsWith('ru') ? 'ru' : 'en';
    return require(`./i18n/strings_${lang}.json`)[key] || require('./i18n/strings_en.json')[key] || key;
  }
  client() {
    if (!this.api) {
      const keyPath = this.router.pluginManager.getConfigurationFile(this.context, 'api-key');
      this.api = new ApiClient({ key: fs.readFileSync(keyPath, 'utf8').trim() });
    }
    return this.api;
  }
  notify(error, type = 'error') {
    const code = error?.code || error?.message || error;
    const safe = this.t(code);
    this.router.pushToastMessage(type, 'Яндекс Музыка', safe === code ? this.t('SERVICE_UNAVAILABLE') : safe);
    if (type === 'error') this.logger?.error('[yandex_music] request failed');
  }
  onVolumioStart() { return Q.resolve(); }
  getConfigurationFiles() { return ['config.json']; }
  getPlaybackEngineVersion() { return 1; }
  onStart() {
    if (!this.startPromise) this.startPromise = this.start().finally(() => { this.startPromise = null; });
    return kew(this.startPromise);
  }
  async start() {
    if (this.started) return;
    this.loadQuality();
    const generation = ++this.lifecycleGeneration;
    const cancelled = async () => {
      if (generation === this.lifecycleGeneration) return false;
      if (this.shutdownGeneration === this.lifecycleGeneration) await this.service.stop();
      return true;
    };
    await this.service.start();
    try {
      if (await cancelled()) return;
      let healthy = false;
      for (let i = 0; i < 40; i++) {
        try {
          const health = await this.client().request('GET', '/health');
          if (await cancelled()) return;
          if (health.ready && health.api_version === 1) { healthy = true; break; }
        } catch { /* systemd may still be starting Python */ }
        await new Promise(resolve => setTimeout(resolve, 500));
        if (await cancelled()) return;
      }
      if (!healthy) throw new Error('SERVICE_UNAVAILABLE');
      const api = this.client();
      this.browse = new Browse(api, key => this.t(key), code => this.notify(code, 'info'));
      const mpd = this.router.pluginManager.getPlugin('music_service', 'mpd');
      const onError = error => { void this.wave?.fail(error); this.notify(error); Promise.resolve(this.router.stateMachine.stop?.()).catch(() => {}); };
      const configFile = this.router.pluginManager.getConfigurationFile?.(this.context, 'transport.json');
      this.wave = new Wave(api, this.router);
      const transport = createTransportWithManager(configFile, { mpd, sm: this.router.stateMachine, service: 'yandex_music', onError, onTrackEnd: track => this.wave?.ended(track), getManager: () => this.router.pluginManager.getPlugin('audio_interface', 'playback_engines') });
      this.playback = new Playback(api, mpd, this.router.stateMachine, onError, () => this.quality, transport);
      this.playback.onQuality = info => this.router.broadcastMessage('pushYandexQuality', info);
      this.playback.probeQuality = probeStream;
      this.started = true;
      this.router.volumioAddToBrowseSources({ name: 'Яндекс Музыка', uri: 'yandex_music',
        plugin_type: 'music_service', plugin_name: 'yandex_music', icon: 'fa-music' });
    } catch (error) {
      if (generation === this.lifecycleGeneration) await this.service.stop();
      throw error;
    }
  }
  onStop() { return kew(this.shutdown()); }
  async shutdown() {
    this.shutdownGeneration = ++this.lifecycleGeneration;
    this.started = false; this.loginGeneration++; clearTimeout(this.timer);
    await this.wave?.close(); this.wave = null;
    this.router.volumioRemoveToBrowseSources('Яндекс Музыка');
    if (this.playback) {
      if (this.playback.current()) await this.playback.stop();
      else this.playback.cancel();
      this.playback.transport.close?.();
    }
    this.browse = null; this.playback = null;
    await this.service.stop();
  }
  handleBrowseUri(uri) {
    return kew((async () => {
      if (!this.browse) throw new Error('SERVICE_UNAVAILABLE');
      try { return await this.browse.browse(uri); }
      catch (error) { this.notify(error); throw error; }
    })());
  }
  search(query) {
    return kew(this.browse ? this.browse.search(query).catch(error => { this.notify(error); return []; }) : []);
  }
  getWave() { return kew(this.wave?.get()); }
  startWave(data = {}) {
    const selection = data.selection || Object.fromEntries(Object.entries(data).map(([key, item]) =>
      [key, typeof item === 'object' ? item?.value : item]));
    return kew((async () => { await this.wave?.start(selection); return this.refreshUI(); })());
  }
  stopWave() { return kew((async () => { await this.wave?.stop(); return this.refreshUI(); })()); }
  getPlaybackQuality() {
    const info = this.playback?.current() ? this.playback.lastQuality : null;
    this.router.broadcastMessage('pushYandexQuality', info || {});
    return Q.resolve();
  }
  getLocalFileInfo(data) {
    return kew((async () => {
      const uri = typeof data?.uri === 'string' ? data.uri : '';
      const info = await this.localFiles.get(uri);
      this.router.broadcastMessage('pushLocalFileInfo', info || { uri });
    })());
  }
  getRecordingQuality(data) {
    return kew((async () => {
      const uri = typeof data?.uri === 'string' ? data.uri : '';
      const match = /^yandex_music\/track\/(\d{1,24}(?:(?:%3A|:)\d{1,24})?)$/i.exec(uri);
      if (!match) return;
      let recordingQuality = null;
      try {
        const result = await this.client().request('GET', `/v1/tracks/${encodeURIComponent(decodeURIComponent(match[1]))}/quality`);
        const q = result?.recording_quality;
        if (q?.basis === 'available' && ['flac', 'mp3'].includes(q.codec)) {
          recordingQuality = { codec: q.codec, basis: 'available',
            ...(q.codec === 'mp3' && Number.isFinite(q.bitrate) && q.bitrate > 0 && q.bitrate <= 320 ? { bitrate: q.bitrate } : {}) };
        }
      } catch { /* Optional metadata must not interrupt browsing or expose errors. */ }
      this.router.broadcastMessage('pushRecordingQuality', { uri, recordingQuality });
    })());
  }
  explodeUri(uri) {
    const track = this.wave?.tracks.get(uri);
    return kew(track ? [track] : this.browse ? this.browse.explode(uri) : Promise.reject(new Error('SERVICE_UNAVAILABLE')));
  }
  clearAddPlayTrack(track) { return kew(this.playback?.clearAddPlayTrack(track)); }
  pause() { return kew(this.playback?.pause()); }
  resume() { return kew(this.playback?.resume()); }
  stop() { return kew(this.playback?.stop()); }
  // Volumio invokes stop() on the music service, while lifecycle uses onStop().
  seek(position) { return kew(this.playback?.seek(position)); }
  next() { return kew(this.playback?.next()); }
  previous() { return kew(this.playback?.previous()); }
  getUIConfig() { return kew(this.uiConfig()); }
  async uiConfig() {
    const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'UIConfig.json'), 'utf8'));
    const account = config.sections[0];
    account.label = this.t('account');
    for (const item of account.content) item.label = this.t(item.id);
    try {
      const status = await this.client().request('GET', '/v1/account');
      account.description = status.authenticated ? `${this.t('signedIn')}: ${status.user.name}` : this.t('signedOut');
    } catch { account.description = this.t('SERVICE_UNAVAILABLE'); }
    if (this.login) {
      account.description += ` · ${this.t(this.login.status)} · ${this.t('code')}: ${this.login.user_code}`;
      const link = account.content.find(item => item.id === 'verification');
      link.hidden = false; link.onClick.url = this.login.verification_url;
    }
    config.sections[1].label = this.t('manual');
    config.sections[1].description = this.t('manualDescription');
    config.sections[1].saveButton.label = this.t('save');
    const audio = config.sections[2];
    audio.label = this.t('audio'); audio.saveButton.label = this.t('saveSettings');
    const setting = audio.content[0]; setting.label = this.t('quality');
    setting.options = ['auto', 'lossless', 'mp3'].map((value, i) => ({ value, label: this.t(['qualityAuto', 'qualityLossless', 'qualityMp3'][i]) }));
    setting.value = setting.options.find(option => option.value === this.quality);
    if (this.wave) {
      const wave = await this.wave.get();
      const fields = Object.keys(wave.options);
      config.sections.push({ id: 'wave', element: 'section', label: 'Моя волна',
        description: wave.error || (wave.active ? 'Волна играет' : 'Волна остановлена'),
        onSave: { type: 'controller', endpoint: 'music_service/yandex_music', method: 'startWave' },
        saveButton: { label: wave.active ? 'Применить и перезапустить' : 'Запустить', data: fields },
        content: [...fields.map(id => {
          const options = [{ value: '', label: id === 'activity' ? 'Моя волна' : 'По умолчанию' }, ...wave.options[id].values];
          return { id, element: 'select', label: wave.options[id].label, options,
            value: options.find(o => o.value === wave.selection[id]) || options[0] };
        }), { id: 'stopWave', element: 'button', label: 'Остановить',
          onClick: { type: 'controller', endpoint: 'music_service/yandex_music', method: 'stopWave' } }]
      });
    }
    return config;
  }
  saveQuality(data) {
    return kew((async () => {
      const quality = typeof data.quality === 'object' ? data.quality?.value : data.quality;
      if (!['auto', 'lossless', 'mp3'].includes(quality)) throw new Error('BAD_REQUEST');
      const filename = this.qualityPath();
      if (!filename) throw new Error('SERVICE_UNAVAILABLE');
      fs.writeFileSync(filename, JSON.stringify({ quality }), { mode: 0o600 });
      this.quality = quality;
      return this.refreshUI();
    })());
  }
  refreshSettings() { return kew(this.refreshUI()); }
  async refreshUI() {
    const config = await this.uiConfig();
    this.router.broadcastMessage('pushUiConfig', config);
    return config;
  }
  startLogin() {
    return kew((async () => {
      try {
        const generation = ++this.loginGeneration;
        clearTimeout(this.timer);
        this.login = await this.client().request('POST', '/v1/auth/device', {});
        await this.refreshUI();
        this.pollLogin(generation);
      } catch (error) { this.notify(error); }
    })());
  }
  pollLogin(generation) {
    this.timer = setTimeout(async () => {
      if (!this.started || generation !== this.loginGeneration) return;
      try {
        const status = await this.client().request('GET', `/v1/auth/device/${encodeURIComponent(this.login.id)}`);
        if (!this.started || generation !== this.loginGeneration) return;
        this.login = status;
        await this.refreshUI();
        if (status.status === 'pending') this.pollLogin(generation);
        else if (status.status === 'success') { await this.wave?.stop(false); this.notify('success', 'success'); }
      } catch (error) { this.notify(error); }
    }, 3000);
    this.timer.unref?.();
  }
  saveToken(data) {
    return kew((async () => {
      try {
        this.loginGeneration++; clearTimeout(this.timer);
        await this.wave?.stop(false);
        await this.client().request('POST', '/v1/auth/token', { token: data.token });
        this.login = null;
        this.notify('success', 'success');
      } catch (error) { this.notify(error); }
      return this.refreshUI();
    })());
  }
  logout() {
    return kew((async () => {
      try {
        this.loginGeneration++; clearTimeout(this.timer); this.login = null;
        await this.wave?.stop(false);
        if (this.playback?.current()) await this.playback.stop();
        await this.client().request('POST', '/v1/auth/logout', {});
      } catch (error) { this.notify(error); }
      return this.refreshUI();
    })());
  }
}
module.exports = ControllerYandexMusic;
