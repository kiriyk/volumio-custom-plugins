'use strict';

/*
 * Artwork One — the interface as a Volumio plugin.
 *
 * Two jobs. The interface itself: static files under ui/, registered with Volumio as a third-party
 * interface on start (Settings → System → User Interface layout design), taken out again on stop.
 * And the place the interface keeps its settings: the theme (dark, light, system), the ambient
 * display, the pins and the sources shown in the menu — a set of static files has nowhere to keep anything, so a choice made in
 * one browser never reached another, and a display the player drives on HDMI could not be told
 * anything at all. The plugin answers a screen that asks and pushes every accepted change to all.
 *
 * Contract (the interface's side: core/store/companion.ts):
 *   callMethod user_interface/artwork_one getSettings {}             -> pushArtworkSettings to the caller
 *   callMethod user_interface/artwork_one setSettings {theme?, ambient?, pins?, menu?, menuOrder?}
 *                                                                    -> pushArtworkSettings to everyone
 * A key is absent until someone chooses it. A partial payload never clears the other keys.
 * (The interface also asks the old endpoint miscellanea/artwork_companion, for a script install
 * that still has the Companion; whichever answers first is followed — core/store/companion.ts.)
 *
 * Volumio registers a third-party interface by path and never unregisters: an entry disappears
 * only when its folder is gone, and a second entry for the same name is added when the path
 * differs. So the plugin removes the script install's entry (/data/artwork-ui) when it starts,
 * and its own when it stops — switching the player to another interface first when it is the
 * active one, so nobody is left on a page that no longer exists.
 *
 * kew and v-conf are declared in package.json. A copy put in place by hand without node_modules
 * gets them from the core tree. The optional MusicBrainz proxy uses the bundled undici module.
 */

// kew and v-conf are declared in package.json (Volumio installs them with the plugin); the core
// tree is the fallback for a copy put in place by hand, without node_modules
function core(name) {
  try { return require(name); } catch (e) { return require('/volumio/node_modules/' + name); }
}
var libQ = core('kew');
var VConf = core('v-conf');
var fs = require('fs');
var path = require('path');
var randomUUID = require('node:crypto').randomUUID;
var execFileSync = require('child_process').execFileSync;
var LocalMusicService = require('./local-music-service').LocalMusicService;
var { DEFAULT_CACHE_MIB, MIB } = require('./local-music-cache');

var THEMES = ['dark', 'light', 'system'];
var DELAYS = [-1, 0, 1, 2, 5, 10];   // -1: always in ambient
var TEXT_SIZES = ['s', 'm', 'l', 'xl'];
var LAYOUTS = ['cover', 'clock', 'bleed'];
var BACKGROUNDS = ['still', 'aurora'];   // the blurred cover alone, or soft colours from it drifting behind
var CLOCKS = ['24', '12'];
var EVENT = 'pushArtworkSettings';

var UI_NAME = 'artwork';
var UI_PRETTY_NAME = 'Artwork One';
// the files the plugin reads and writes (under a test root when the tests run)
var ROOT = process.env.ARTWORK_ONE_TEST_ROOT || '';
var PATHS = {
  UI_DIR: ROOT ? path.join(ROOT, 'ui') : path.join(__dirname, 'ui'),
  MUSIC_CACHE: ROOT + '/data/artwork-one-music-cache',
  MUSICBRAINZ_PROXY: ROOT + '/data/configuration/user_interface/artwork_one/musicbrainz-proxy',
  UI_LIST: ROOT + '/data/thirdPartyUisList.json',
  ACTIVE_UI: ROOT + '/data/active_volumio_ui',
  CORE_UI_LIST: ROOT + '/volumio/volumioUisList.json',
  SCRIPT_INSTALL: ROOT + '/data/artwork-ui',   // Artwork One 1.x–3.1 put by the older scripts/install.sh
  OLD_CONF: ROOT + '/data/configuration/miscellanea/artwork_companion/config.json',
  DOWNLOAD: ROOT + '/tmp/downloaded_plugin.zip',   // where the core puts a plugin it is about to install or update
  CORE_TEMP: ROOT + '/data/temp'                    // where it unpacks it; removed when the update ends, well or not
};
var PLUGIN_NAME = 'artwork_one';
var MUSIC_ENDPOINTS = [
  { endpoint: 'artworkOneLocalMusicInfo', type: 'user_interface', name: PLUGIN_NAME, method: 'getLocalMusicInfo' },
  { endpoint: 'artworkOneMusicBrainz', type: 'user_interface', name: PLUGIN_NAME, method: 'getMusicBrainz' },
  { endpoint: 'artworkOneLocalFileInfo', type: 'user_interface', name: PLUGIN_NAME, method: 'getLocalFileInfo' }
];
var UPDATE_POLL = 1000, UPDATE_GIVE_UP = 10 * 60 * 1000;

module.exports = ArtworkOne;

function ArtworkOne(context) {
  this.context = context;
  this.commandRouter = context.coreCommand;
  this.logger = context.logger;
  this.configManager = context.configManager;
  this.config = new VConf();
  this.paths = Object.assign({}, PATHS);
}

ArtworkOne.prototype.getConfigurationFiles = function () {
  return ['config.json'];
};

ArtworkOne.prototype.onVolumioStart = function () {
  this.configFile = this.commandRouter.pluginManager.getConfigurationFile(this.context, 'config.json');
  this.config.loadFile(this.configFile);
  return libQ.resolve();
};

ArtworkOne.prototype.onStart = function () {
  var self = this;
  try {
    var fresh = self.isFreshInstall();   // asked before the script install's settings are taken over
    self.takeOverScriptInstall();
    self.registerUI();
    if (fresh) { self.introduce(); } else { self.comeBack(); }
    self.startLocalMusic();
  } catch (e) {
    self.logger.error('[artwork_one] start failed: ' + e);
    return libQ.reject(new Error('Artwork One could not register its interface: ' + e));
  }
  self.logger.info('[artwork_one] started; ' + JSON.stringify(self.snapshot()));
  return libQ.resolve();
};

// Stopped — disabled or uninstalled: the interface leaves Volumio's list, and a player showing it is
// switched to a core interface first, so nobody is left on a page nothing answers for. That it was the
// active one is remembered: the next start brings it back.
// Stopped for an update (the core stops a plugin before replacing its files, and starts it again only
// with Volumio): the interface stays where it is — the new files arrive in the same folder — and the
// plugin starts itself again once the core is done, so it does not sit there "On" but inactive with the
// player switched to Manifest until the next restart.
ArtworkOne.prototype.onStop = function () {
  var self = this;
  try {
    self.stopLocalMusic();
    var active = self.isActive();
    self.config.set('wasActive', active);
    if (self.isBeingUpdated()) {
      self.logger.info('[artwork_one] stopped for an update: the interface stays, the plugin starts again when it is done');
      self.awaitUpdate(active);
      return libQ.resolve();
    }
    if (active) { self.switchToCoreUI(); }
    self.unregisterUI();
  } catch (e) { self.logger.error('[artwork_one] stop: ' + e); }
  return libQ.resolve();
};

// the core has downloaded a package and is stopping this plugin: an update of Artwork One (a disable or an
// uninstall downloads nothing; an install of another plugin stops none). The package's own name decides.
ArtworkOne.prototype.isBeingUpdated = function () {
  var exists = false;
  try { exists = fs.existsSync(this.paths.DOWNLOAD); } catch (e) { exists = false; }
  return exists && this.packageName(this.paths.DOWNLOAD) === PLUGIN_NAME;
};
// the name in a plugin package's package.json, with the unzip the core itself uses ('' when unreadable)
ArtworkOne.prototype.packageName = function (zip) {
  var dir = path.join(require('os').tmpdir(), 'artwork-one-peek-' + process.pid);
  try {
    fs.mkdirSync(dir, { recursive: true });   // miniunzip will not create it
    execFileSync('/usr/bin/miniunzip', ['-o', zip, 'package.json', '-d', dir], { timeout: 10000, stdio: 'ignore' });
    return String(this.readJson(path.join(dir, 'package.json'), {}).name || '');
  } catch (e) { return ''; }
  finally { try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) { /* only a temp folder */ } }
};

// waits for the core to finish (it removes the download and its temp folder at the end, on success and on
// failure alike), then starts the plugin through the core — its status reads STARTED again — and reloads
// the screens that showed Artwork One, so they load the new files. A failed update that left no interface
// behind switches the player to a core interface, as a stop would have.
ArtworkOne.prototype.awaitUpdate = function (wasActive) {
  var self = this, started = Date.now();
  var busy = function () { try { return fs.existsSync(self.paths.DOWNLOAD) || fs.existsSync(self.paths.CORE_TEMP); } catch (e) { return false; } };
  var tick = function () {
    if (busy() && Date.now() - started < UPDATE_GIVE_UP) { self.updateTimer = setTimeout(tick, UPDATE_POLL); return; }
    self.updateTimer = null;
    self.afterUpdate(wasActive);
  };
  self.updateTimer = setTimeout(tick, UPDATE_POLL);
};
ArtworkOne.prototype.afterUpdate = function (wasActive) {
  var self = this;
  var hasUi = false;
  try { hasUi = fs.existsSync(path.join(self.paths.UI_DIR, 'index.html')); } catch (e) { hasUi = false; }
  if (!hasUi) {
    self.logger.warn('[artwork_one] the update left no interface behind');
    try { if (self.isActive()) { self.switchToCoreUI(); } self.unregisterUI(); } catch (e) { self.logger.error('[artwork_one] after the update: ' + e); }
    return;
  }
  libQ.resolve()
    .then(function () { return self.commandRouter.pluginManager.startPlugin('user_interface', PLUGIN_NAME); })
    .then(function () {
      self.logger.info('[artwork_one] updated and started again');
      if (wasActive && self.isActive()) { self.setActiveUI(UI_NAME); }   // the Appearance switch reloads every screen: the new files load
    })
    .fail(function (e) { self.logger.error('[artwork_one] could not start again after the update: ' + e); });
};

// the player showed Artwork One when the plugin was last stopped (an update, or a disable the user
// has just undone): it does again, with the Appearance plugin's own switch when that one is up —
// a toast and a reload for the screens — and by hand when it is not yet (at boot nobody is watching)
ArtworkOne.prototype.comeBack = function () {
  if (!this.config.get('wasActive')) { return; }
  this.config.set('wasActive', false);
  if (this.activate()) { this.logger.info('[artwork_one] the player showed Artwork One before the stop: it does again'); }
};

// The first start after an installation: whoever installed and enabled the plugin wants to see it, so the
// player switches to it (once — later starts leave the choice alone, and someone who went back to another
// interface stays there). An installation is a configuration with nothing in it: Volumio deletes it on an
// uninstall, an update from the store keeps it (the stop before it writes wasActive), and a player that ran
// the older script install brings its settings across first.
ArtworkOne.prototype.isFreshInstall = function () {
  try { return this.config.getKeys().length === 0; } catch (e) { return false; }
};
ArtworkOne.prototype.introduce = function () {
  this.config.set('introduced', true);
  try { this.config.save(); } catch (e) { /* v-conf writes it within a second anyway */ }   // at once: a restart right after must not switch again
  if (this.activate()) { this.logger.info('[artwork_one] installed and enabled: the player shows Artwork One'); }
};

// switches the player to Artwork One, with the Appearance plugin's own switch when that one is up — a toast
// and a reload for the screens — and by hand when it is not yet (at boot nobody is watching). Returns whether
// it switched (false when Artwork One was showing already).
ArtworkOne.prototype.activate = function () {
  if (this.isActive()) { return false; }
  try { this.setActiveUI(UI_NAME); } catch (e) { this.logger.warn('[artwork_one] appearance switch: ' + e); }
  if (!this.isActive()) {
    this.writeJson(this.paths.ACTIVE_UI, this.uiEntry());
    process.env.VOLUMIO_ACTIVE_UI_PATH = this.paths.UI_DIR; process.env.VOLUMIO_ACTIVE_UI_NAME = UI_NAME; process.env.VOLUMIO_ACTIVE_UI_PRETTY_NAME = UI_PRETTY_NAME;
  }
  return true;
};

// --- the interface in Volumio's list --------------------------------------------------------

ArtworkOne.prototype.uiEntry = function () { return { uiPrettyName: UI_PRETTY_NAME, uiName: UI_NAME, uiPath: this.paths.UI_DIR }; };

ArtworkOne.prototype.readJson = function (file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return fallback; }
};
ArtworkOne.prototype.writeJson = function (file, data) {
  try { fs.writeFileSync(file, JSON.stringify(data, null, 2)); return true; }
  catch (e) { this.logger.error('[artwork_one] could not write ' + file + ': ' + e); return false; }
};

ArtworkOne.prototype.registerUI = function () {
  var hasUi = false;
  try { hasUi = fs.existsSync(path.join(this.paths.UI_DIR, 'index.html')); } catch (e) { hasUi = false; }
  if (!hasUi) { throw new Error('ui/index.html is missing'); }
  // Volumio adds by path and keeps every path: ours only once, and nothing else under our name
  var list = this.readJson(this.paths.UI_LIST, []);
  var dir = this.paths.UI_DIR;
  if (!Array.isArray(list)) { list = []; }
  list = list.filter(function (u) { return u && u.uiName !== UI_NAME && u.uiPath !== dir; });
  list.push(this.uiEntry());
  this.writeJson(this.paths.UI_LIST, list);
  this.commandRouter.registerThirdPartyUI(this.uiEntry());   // the core's own bookkeeping (a no-op now, the entry is there)
  this.logger.info('[artwork_one] interface registered at ' + this.paths.UI_DIR);
};

ArtworkOne.prototype.unregisterUI = function () {
  var list = this.readJson(this.paths.UI_LIST, []);
  var dir = this.paths.UI_DIR;
  if (!Array.isArray(list)) { return; }
  var kept = list.filter(function (u) { return u && u.uiPath !== dir; });
  if (kept.length !== list.length) { this.writeJson(this.paths.UI_LIST, kept); this.logger.info('[artwork_one] interface unregistered'); }
};

// Artwork One 1.x–3.1 was put in /data/artwork-ui by a script, with the same uiName: without this the
// interface would be listed twice, and the player might still serve the old files. The plugin takes
// the entry over (the files are left alone: the uninstaller of that install knows about them).
ArtworkOne.prototype.takeOverScriptInstall = function () {
  var active = this.readJson(this.paths.ACTIVE_UI, null);
  if (active && active.uiPath === this.paths.SCRIPT_INSTALL) {
    this.writeJson(this.paths.ACTIVE_UI, this.uiEntry());
    process.env.VOLUMIO_ACTIVE_UI_PATH = this.paths.UI_DIR; process.env.VOLUMIO_ACTIVE_UI_NAME = UI_NAME; process.env.VOLUMIO_ACTIVE_UI_PRETTY_NAME = UI_PRETTY_NAME;
    this.logger.info('[artwork_one] the active interface was the script install: now the plugin\'s');
  }
  // the old companion's settings come along, once
  var oldConf = this.paths.OLD_CONF;
  var hasOld = false;
  try { hasOld = !this.config.get('migrated') && fs.existsSync(oldConf); } catch (e) { hasOld = false; }
  if (hasOld) {
    var old = this.readJson(oldConf, {});
    var self = this;
    ['theme', 'ambient', 'pins'].forEach(function (k) { if (old[k] && old[k].value !== undefined && old[k].value !== '' && !self.config.get(k)) { self.config.set(k, old[k].value); } });
    this.config.set('migrated', true);
    this.logger.info('[artwork_one] settings taken over from the Artwork One Companion');
  }
};

// --- the active interface -------------------------------------------------------------------

ArtworkOne.prototype.isActive = function () {
  var active = this.readJson(this.paths.ACTIVE_UI, null);
  return !!(active && active.uiPath === this.paths.UI_DIR);
};

// the Appearance plugin's own switch: writes the flag file, updates the live env, pushes a toast, reloads every screen
ArtworkOne.prototype.setActiveUI = function (uiName) {
  return this.commandRouter.executeOnPlugin('miscellanea', 'appearance', 'setVolumio3UI', { volumio3_ui: { value: uiName } });
};

ArtworkOne.prototype.switchToCoreUI = function () {
  var core = this.readJson(this.paths.CORE_UI_LIST, []);
  var exists = function (p) { try { return fs.existsSync(p); } catch (e) { return false; } };
  var next = (Array.isArray(core) ? core : []).filter(function (u) { return u && u.uiName !== UI_NAME && u.uiPath && exists(u.uiPath); })[0];
  if (!next) { this.logger.warn('[artwork_one] no core interface found to switch to'); return; }
  this.logger.info('[artwork_one] switching the player to ' + next.uiPrettyName);
  this.setActiveUI(next.uiName);
};

// the button on the plugin's page
ArtworkOne.prototype.switchTo = function () {
  var self = this;
  try {
    if (self.isActive()) {
      self.commandRouter.pushToastMessage('info', UI_PRETTY_NAME, self.t('ACTIVE'));
      return libQ.resolve();
    }
    self.setActiveUI(UI_NAME);   // the entry is there since onStart; Appearance looks it up by name
  } catch (e) {
    self.logger.error('[artwork_one] switch: ' + e);
    self.commandRouter.pushToastMessage('error', UI_PRETTY_NAME, String(e.message || e));
  }
  return libQ.resolve();
};

ArtworkOne.prototype.t = function (key) {
  var lang = this.commandRouter.sharedVars.get('language_code');
  var strings = this.readJson(path.join(__dirname, 'i18n', 'strings_' + lang + '.json'), null);
  return strings?.ARTWORK_ONE?.[key] || this.readJson(path.join(__dirname, 'i18n', 'strings_en.json'), {}).ARTWORK_ONE?.[key] || key;
};
ArtworkOne.prototype.onRestart = function () {};

// --- the settings page: one line that says where the settings really are -------------------

ArtworkOne.prototype.getUIConfig = function () {
  return libQ.resolve((async () => {
    const lang = this.commandRouter.sharedVars.get('language_code');
    const uiconf = await this.commandRouter.i18nJson(
      path.join(__dirname, 'i18n', 'strings_' + lang + '.json'),
      path.join(__dirname, 'i18n', 'strings_en.json'),
      path.join(__dirname, 'UIConfig.json')
    );
    const active = this.isActive();
    const status = uiconf.sections[0].content[0];
    status.value = this.t(active ? 'ACTIVE' : 'INACTIVE');
    if (active) uiconf.sections[0].content[1].hidden = true;
    uiconf.sections[1].content[0].value = fs.existsSync(this.paths.MUSICBRAINZ_PROXY);
    const cache = this.localMusic?.cache;
    const limit = cache ? cache.maxBytes / MIB : this.musicCacheSize();
    const usage = cache ? await cache.usage() : 0;
    const [filled, size] = uiconf.sections[2].content;
    filled.value = this.t('CACHE_USAGE_VALUE')
      .replace('{used}', new Intl.NumberFormat(String(lang || 'en').replace('_', '-'), { maximumFractionDigits: 2 }).format(usage / MIB))
      .replace('{limit}', limit);
    size.value = limit;
    return uiconf;
  })());
};

ArtworkOne.prototype.setUIConfig = function () {};
ArtworkOne.prototype.getConf = function (key) { return this.config.get(key); };
ArtworkOne.prototype.setConf = function (key, value) { this.config.set(key, value); };

// --- what the screens ask ------------------------------------------------------------------

// everything a screen needs, with only the keys that were ever chosen
ArtworkOne.prototype.snapshot = function () {
  var out = { version: 2, plugin: 'user_interface/artwork_one' };   // which plugin answers: the interface addresses it from then on
  var theme = this.config.get('theme');
  if (THEMES.indexOf(theme) > -1) { out.theme = theme; }
  var ambient = this.readAmbient();
  if (ambient) { out.ambient = ambient; }
  var pins = this.readPins();
  if (pins) { out.pins = pins; }
  var menu = this.readMenu();
  if (menu) { out.menu = menu; }
  var order = this.readMenuOrder();
  if (order) { out.menuOrder = order; }
  return out;
};

// the menu: the library's sources shown in the rail or not, by uri ({ randomizer: true, favourites: false });
// a source nobody chose keeps the interface's default
ArtworkOne.prototype.readMenu = function () {
  var raw = this.config.get('menu');
  if (!raw) { return null; }
  try { return this.cleanMenu(typeof raw === 'string' ? JSON.parse(raw) : raw); } catch (e) { return null; }
};

// the menu's order: the sources' uris as the menu shows them (a source not listed follows, in Volumio's order)
ArtworkOne.prototype.readMenuOrder = function () {
  var raw = this.config.get('menuOrder');
  if (!raw) { return null; }
  try { return this.cleanMenuOrder(typeof raw === 'string' ? JSON.parse(raw) : raw); } catch (e) { return null; }
};

ArtworkOne.prototype.cleanMenuOrder = function (list) {
  if (!Array.isArray(list)) { return null; }
  var out = [];
  list.forEach(function (uri) { if (typeof uri === 'string' && uri && uri.length <= 200 && out.indexOf(uri) < 0 && out.length < 60) { out.push(uri); } });
  return out.length ? out : null;
};

ArtworkOne.prototype.cleanMenu = function (m) {
  if (!m || typeof m !== 'object' || Array.isArray(m)) { return null; }
  var out = {}, n = 0;
  Object.keys(m).forEach(function (uri) {
    if (!uri || uri.length > 200 || typeof m[uri] !== 'boolean' || n >= 60) { return; }
    out[uri] = m[uri]; n++;
  });
  return n ? out : null;
};

// the pins: quick access on Home, up to 24, each only what a tile needs
ArtworkOne.prototype.readPins = function () {
  var raw = this.config.get('pins');
  if (!raw) { return null; }
  try { return this.cleanPins(typeof raw === 'string' ? JSON.parse(raw) : raw); } catch (e) { return null; }
};

ArtworkOne.prototype.cleanPins = function (list) {
  if (!Array.isArray(list)) { return null; }
  var out = [], seen = {};
  list.forEach(function (p) {
    if (!p || typeof p !== 'object' || !p.uri || seen[p.uri] || out.length >= 24) { return; }
    seen[p.uri] = true;
    var pin = { uri: String(p.uri).slice(0, 600), service: String(p.service || '').slice(0, 40), type: String(p.type || '').slice(0, 40), title: String(p.title || '').slice(0, 200) };
    if (p.albumart) { pin.albumart = String(p.albumart).slice(0, 600); }
    if (p.artist) { pin.artist = String(p.artist).slice(0, 200); }
    if (p.album) { pin.album = String(p.album).slice(0, 200); }
    out.push(pin);
  });
  return out;
};

ArtworkOne.prototype.readAmbient = function () {
  var raw = this.config.get('ambient');
  if (!raw) { return null; }
  try { return this.cleanAmbient(typeof raw === 'string' ? JSON.parse(raw) : raw); } catch (e) { return null; }
};

// keeps only the fields the interface knows, each in its own range
ArtworkOne.prototype.cleanAmbient = function (a) {
  if (!a || typeof a !== 'object') { return null; }
  var out = {};
  if (typeof a.on === 'boolean') { out.on = a.on; }
  if (DELAYS.indexOf(Number(a.delay)) > -1) { out.delay = Number(a.delay); }
  if (LAYOUTS.indexOf(a.layout) > -1) { out.layout = a.layout; }
  if (BACKGROUNDS.indexOf(a.background) > -1) { out.background = a.background; }
  if (CLOCKS.indexOf(String(a.clock)) > -1) { out.clock = String(a.clock); }
  if (typeof a.night === 'boolean') { out.night = a.night; }
  if (isTime(a.nightFrom)) { out.nightFrom = a.nightFrom; }
  if (isTime(a.nightTo)) { out.nightTo = a.nightTo; }
  if (TEXT_SIZES.indexOf(a.textSize) > -1) { out.textSize = a.textSize; }   // the display's own text size and volume
  if (typeof a.hideVolume === 'boolean') { out.hideVolume = a.hideVolume; }
  if (typeof a.keysWake === 'boolean') { out.keysWake = a.keysWake; }   // a remote that types (Flirc) may leave the ambient screen up
  if (typeof a.transparency === 'boolean') { out.transparency = a.transparency; }   // the display's frosted glass, or solid surfaces
  if (typeof a.queueNo === 'boolean') { out.queueNo = a.queueNo; }   // the place in the queue (#21) after the album on the ambient screen
  return Object.keys(out).length ? out : null;
};

function isTime(v) { return /^([01]?\d|2[0-3]):[0-5]\d$/.test(String(v || '')); }

function musicBrainzProxyUrl(value) {
  try {
    var proxy = new URL(value);
    if (['http:', 'https:'].includes(proxy.protocol) && proxy.pathname === '/' && !proxy.search && !proxy.hash) return proxy.href;
  } catch {}
  throw new Error('Invalid MusicBrainz HTTP proxy URL');
}

function readMusicBrainzProxy(filename) {
  var value;
  try { value = fs.readFileSync(filename, 'utf8').trim(); }
  catch (error) {
    if (error.code === 'ENOENT') return undefined;
    throw error;
  }
  try {
    return new (require('undici').ProxyAgent)(musicBrainzProxyUrl(value));
  } catch {
    throw new Error('Unable to configure MusicBrainz HTTP proxy');
  }
}

ArtworkOne.prototype.saveMusicBrainzProxy = function (data) {
  var filename = this.paths.MUSICBRAINZ_PROXY;
  var value = typeof data?.proxyUrl === 'string' ? data.proxyUrl.trim() : '';
  var proxy;
  try {
    if (typeof data?.proxyEnabled !== 'boolean') throw new Error('Invalid proxy setting');
    if (!data.proxyEnabled) {
      fs.rmSync(filename, { force: true });
      this.localMusic?.catalog.setProxy(undefined);
    } else if (value) {
      var url = musicBrainzProxyUrl(value);
      if (this.localMusic) proxy = new (require('undici').ProxyAgent)(url);
      var temp = filename + '.' + randomUUID();
      try {
        fs.writeFileSync(temp, url + '\n', { mode: 0o600, flag: 'wx' });
        fs.renameSync(temp, filename);
      } finally { fs.rmSync(temp, { force: true }); }
      this.localMusic?.catalog.setProxy(proxy);
    } else if (!fs.existsSync(filename)) {
      throw new Error('A proxy URL is required');
    }
    this.commandRouter.pushToastMessage('success', UI_PRETTY_NAME, this.t('PROXY_SAVED'));
  } catch {
    void proxy?.destroy().catch(() => {});
    this.commandRouter.pushToastMessage('error', UI_PRETTY_NAME, this.t('PROXY_ERROR'));
  }
  this.getUIConfig().then(config => this.commandRouter.broadcastMessage('pushUiConfig', config))
    .fail(() => this.logger.warn('[artwork_one] could not refresh proxy settings'));
};

ArtworkOne.prototype.startLocalMusic = function () {
  if (this.localMusic) return;
  var musicBrainzProxy = readMusicBrainzProxy(this.paths.MUSICBRAINZ_PROXY);
  this.localMusic = new LocalMusicService(this.commandRouter, this.paths.MUSIC_CACHE, {
    logger: this.logger, musicBrainzProxy, maxBytes: this.musicCacheSize() * MIB
  });
  MUSIC_ENDPOINTS.forEach(endpoint => this.commandRouter.addPluginRestEndpoint(endpoint));
};

ArtworkOne.prototype.stopLocalMusic = function () {
  if (!this.localMusic) return;
  this.localMusic.stop();
  this.localMusic = null;
  MUSIC_ENDPOINTS.forEach(endpoint => this.commandRouter.removePluginRestEndpoint(endpoint));
};

ArtworkOne.prototype.getLocalMusicInfo = function (data) {
  var language = String(this.commandRouter.sharedVars.get('language_code') || 'en').toLowerCase().split(/[-_]/)[0];
  return this.localMusic ? this.localMusic.resolve({ locale: language, ...data }) : { requestId: data?.requestId, error: 'temporaryError' };
};

ArtworkOne.prototype.getMusicBrainz = function (data) {
  return this.localMusic?.musicBrainz(data);
};

ArtworkOne.prototype.getLocalFileInfo = function (data) {
  return this.localMusic?.fileInfo(data?.uri);
};

ArtworkOne.prototype.musicCacheSize = function () {
  const size = this.config.get('musicCacheMiB');
  return Number.isSafeInteger(size) && size >= 1 && size <= 4096 ? size : DEFAULT_CACHE_MIB;
};

ArtworkOne.prototype.changeMusicCache = async function (success, action) {
  try {
    if (!this.localMusic) throw new Error('Cache is unavailable');
    await action(this.localMusic.cache);
    this.commandRouter.broadcastMessage('pushUiConfig', await this.getUIConfig());
    this.commandRouter.pushToastMessage('success', UI_PRETTY_NAME, this.t(success));
  } catch (error) {
    this.logger.warn('[artwork_one] cache settings: ' + (error.code || error.message));
    this.commandRouter.pushToastMessage('error', UI_PRETTY_NAME, this.t('CACHE_ERROR'));
  }
};

ArtworkOne.prototype.saveMusicCacheSize = function (data) {
  return libQ.resolve(this.changeMusicCache('CACHE_SAVED', async cache => {
    const size = Number(data?.cacheSize);
    if (!Number.isSafeInteger(size) || size < 1 || size > 4096) throw new Error('Invalid cache size');
    await cache.resize(size * MIB);
    this.config.set('musicCacheMiB', size);
  }));
};

ArtworkOne.prototype.clearMusicCache = function () {
  return libQ.resolve(this.changeMusicCache('CACHE_CLEARED', async cache => {
    await cache.clear();
    this.commandRouter.broadcastMessage('pushArtworkCacheCleared', {});
  }));
};

// callMethod → answered to the caller only
ArtworkOne.prototype.getSettings = function () {
  return { message: EVENT, payload: this.snapshot() };
};

// callMethod → saved, then pushed to every screen
ArtworkOne.prototype.setSettings = function (data) {
  var d = data || {};
  var changed = false;
  if (d.theme !== undefined) {
    if (d.theme === null || d.theme === '') { this.config.set('theme', ''); changed = true; }   // '' = nobody chose; v-conf keeps the key
    else if (THEMES.indexOf(d.theme) > -1) { this.config.set('theme', d.theme); changed = true; }
    else { this.logger.warn('[artwork_one] refused theme ' + JSON.stringify(d.theme)); }
  }
  if (d.ambient !== undefined) {
    if (d.ambient === null) { this.config.set('ambient', ''); changed = true; }
    else {
      // the patch is cleaned first: a field out of range is dropped, never the stored one
      var patch = this.cleanAmbient(d.ambient);
      if (patch) { this.config.set('ambient', JSON.stringify(Object.assign({}, this.readAmbient() || {}, patch))); changed = true; }
      else { this.logger.warn('[artwork_one] refused ambient ' + JSON.stringify(d.ambient)); }
    }
  }
  if (d.menu !== undefined) {
    // a choice merges into the others: one switch changes one source
    var menu = this.cleanMenu(d.menu);
    if (menu) { this.config.set('menu', JSON.stringify(Object.assign({}, this.readMenu() || {}, menu))); changed = true; }
    else { this.logger.warn('[artwork_one] refused menu'); }
  }
  if (d.menuOrder !== undefined) {
    var order = this.cleanMenuOrder(d.menuOrder);
    if (order) { this.config.set('menuOrder', JSON.stringify(order)); changed = true; }
    else { this.logger.warn('[artwork_one] refused menu order'); }
  }
  if (d.pins !== undefined) {
    var pins = this.cleanPins(d.pins);
    if (pins) { this.config.set('pins', JSON.stringify(pins)); changed = true; }
    else { this.logger.warn('[artwork_one] refused pins'); }
  }
  var snap = this.snapshot();
  if (changed) {
    this.logger.info('[artwork_one] settings ' + JSON.stringify(snap));
    this.commandRouter.broadcastMessage(EVENT, snap);
  }
  return { message: EVENT, payload: snap };
};
